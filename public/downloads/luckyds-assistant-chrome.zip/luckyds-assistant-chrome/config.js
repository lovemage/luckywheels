self.LW_CONFIG = {"origin":"https://luckyds.com","version":"1.0.1"};
